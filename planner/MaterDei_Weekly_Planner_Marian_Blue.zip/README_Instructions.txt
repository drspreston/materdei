====================================================================
MATER DEI CREATIVE — MARIAN BLUE EDITION
Interactive Weekly Planner & Prayer Journal
====================================================================

Thank you for your purchase!

ACCESS CODE: MATER-DEI-2026
ONLINE WEB APP URL (Optional): https://drspreston.github.io/weekly-planner/weekly_planner_marian_blue.html

INCLUDED FILES:
1. Weekly_Planner_Marian_Blue.html  --> Your offline planner app
2. START_HERE_Quick_Start_Guide.pdf   --> Printable 2-page PDF guide
3. START_HERE_Quick_Start_Guide.html  --> Interactive HTML guide

TWO WAYS TO OPEN & SAVE:
- Option 1 (Online & Mobile App): Open the Online Web App URL above in
  Chrome or Safari and enter your access code. On iPhone/Android, tap
  "Add to Home Screen" to install it with the crown icon and use offline.
- Option 2 (Offline Local File): Extract (unzip) all files into a
  permanent folder (e.g., Documents) and double-click
  "Weekly_Planner_Marian_Blue.html" to open in any browser with no internet.

HOW TO USE, EXPORT, BACKUP & RESTORE:
- Navigate Weeks: Use Prev/Next Week buttons or click any date on the
  Calendar to jump straight to that week.
- Highlight Days & Track Habits: Click the star icon on any day card
  to highlight it in gold, and use "+ Add Habit" or click any habit
  name to customize your daily devotion tracker.
- Export PDF: Click "Print / PDF (Landscape)" and choose "Save as PDF"
  in Landscape orientation to export a 1-page dashboard.
- Export Excel: Click "Export Excel" to download a 5-tab spreadsheet
  containing all saved weeks.
- Backup & Restore: Note that the online link and local HTML file store
  data separately in your browser. Scroll to the bottom footer bar and
  click "Download Backup (.json)" regularly. Use "Restore Backup" to
  reload or transfer your .json file between devices or browsers.

--------------------------------------------------------------------
(c) 2026 Mater Dei Creative. All Rights Reserved.
Personal use only. Unauthorized redistribution is prohibited.
====================================================================
